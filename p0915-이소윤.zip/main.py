stu=[]
sno=1

while True:
    print("1. 성적입력")
    print("2. 성적출력")
    print("3. 성적수정")
    print("9. 성적저장")
    choice=int(input("숫자를 입력하시오."))

    if choice==1:
        while True:
            print("[성적입력]")
            no=sno
            name=input(f"{no}.이름(0.취소):")
            if name=="0":break
            kor=int(input("국어 점수:"))
            eng=int(input("영어 점수:"))
            math=int(input("수학 점수:"))
            total=kor+eng+math
            avg=total/3
            rank=0
            stu.append({'no':no,'name':name,'kor':kor,'eng':eng,'math':math,'total':total,'avg':avg,'rank':rank})
            print(f"{name}학생이 저장되었습니다.")
            print()

    elif choice==2:
        print("[성적출력]")
        print()
        print("-"*60)
        print("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}".format("번호,이름,국어,영어,수학,합계,평균,등수)"))
        print("-"*60)
        for s in stu:
            print(f"s['no']")

